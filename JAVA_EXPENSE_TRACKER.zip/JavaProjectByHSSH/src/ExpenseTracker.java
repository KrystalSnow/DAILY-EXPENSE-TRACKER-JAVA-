import java.util.InputMismatchException;
import java.util.Scanner;

public class ExpenseTracker {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        MyMethods expenseManager = new MyMethods();
        boolean exit = false;

        while (!exit) {
            System.out.println("\n^^ Welcome From Expense Tracker System ^^");
            System.out.println("1. Add Expense");
            System.out.println("2. View Expenses");
            System.out.println("3. Delete Expenses");
            System.out.println("4. Sort Expenses by Date");
            System.out.println("5. Sort Expenses by Amount");
            System.out.println("6. Search Expenses by Category");
            System.out.println("7. Search Expenses by Description");
            System.out.println("8. End from the System");
            System.out.print("Choose an option: ");

            try {
                int choice = sc.nextInt();
                sc.nextLine(); // Consume newline

                switch (choice) {
                    case 1:
                        // Add expense
                        expenseManager.addExpense();
                        break;
                    case 2:
                        // View all expenses
                        expenseManager.viewExpenses();
                        break;
                    case 3 :
                        expenseManager.deleteExpense(); // Delete an expense
                        break;
                    case 4:
                        // Sort by date
                        expenseManager.sortExpensesByDate();
                        break;
                    case 5:
                        // Sort by amount
                        expenseManager.sortExpensesByAmount();
                        break;
                    case 6:
                        // Search by category
                        expenseManager.searchExpensesByCategory();
                        break;
                    case 7:
                        // Search by description
                        expenseManager.searchExpensesByDescription();
                        break;
                    case 8:
                        // Exit the system
                        exit = true;
                        System.out.println("Exiting the system. Have a nice day!!!! Goodbye!");
                        break;
                    default:
                        System.out.println("Invalid option. Please choose a valid option.");
                        break;
                }
            } catch (InputMismatchException e) {
                System.out.println("Invalid input. Please enter a number between 1 and 7.");
                sc.next(); // Consume the invalid input
            }
        }

        sc.close();
    }
}
