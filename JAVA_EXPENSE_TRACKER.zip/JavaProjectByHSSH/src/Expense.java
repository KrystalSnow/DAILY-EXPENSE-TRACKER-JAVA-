public class Expense {  //class
     private String date;
     private String category;
     private double amount;
     private String description;
 
     public Expense(String date, String category, double amount, String description) {
         this.date = date;
         this.category = category;
         this.amount = amount;
         this.description = description;
     }
 
     // Getters
     public String getDate() {
         return date;
     }
 
     public String getCategory() {
         return category;
     }
 
     public double getAmount() {
         return amount;
     }
 
     public String getDescription() {
         return description;
     }
    
    // To display expense information at add method
     @Override
     public String toString() {
         return "Date: " + date + ", Category: " + category + ", Amount: $" + amount + ", Description: " + description;
     }
 }
 
 // Custom exception for negative expense amounts
 class NegativeExpenseException extends Exception {
     public NegativeExpenseException(String message) {
         super(message);
     }
 }
 