import java.util.ArrayList;
import java.util.InputMismatchException;
import java.util.Scanner;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.text.ParseException;

public class MyMethods {
    ArrayList<Expense> expenses = new ArrayList<>();
    Scanner sc = new Scanner(System.in);
    int pick;
    SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");

    // Method to add a new expense
    public void addExpense() {
        try {
            // System.out.print("Enter Expense Date (yyyy-MM-dd): ");
            // String date = sc.nextLine();

            String date = getDateInput(); // Get validated date input

            System.out.print("Enter Expense Category: ");
            String category = sc.nextLine();

            // Catching InputMismatchException for invalid expense amounts
            // System.out.print("Enter Expense Amount: ");
            // double amount = sc.nextDouble();
            double amount = getValidAmount(); // Get validated amount input
            // sc.nextLine(); // Consume newline after the double input

            System.out.print("Enter Expense Description: ");
            String description = sc.nextLine();

            // if (amount <= 0) {
            //     throw new NegativeExpenseException("Expense amount cannot be negative or zero.");
            // }

            expenses.add(new Expense(date, category, amount, description));
            System.out.println("Expense added successfully....");

            showPostAddMenu();

       
        } catch (InputMismatchException e) {
            System.out.println("Invalid input format. Please enter a valid number for the amount.");
            sc.next(); // Consume the invalid input
        }
    }

    // Method to get valid date input
    private String getDateInput() {
        while (true) {
            System.out.print("Enter Expense Date (yyyy-MM-dd): ");
            String date = sc.nextLine();

            try {
                dateFormat.parse(date); // Attempt to parse the date
                return date; // Return the valid date
            } catch (ParseException e) {
                System.out.println("Invalid date format. Please enter the date in yyyy-MM-dd format.");
            }
        }
    }

    // Method to get a valid amount input
private double getValidAmount() {
    double amount = 0;
    while (true) {
        try {
            System.out.print("Enter Expense Amount: ");
            amount = sc.nextDouble();
            sc.nextLine(); // Consume newline after the double input
            if (amount <= 0) {
                // Throw a custom exception for zero or negative amounts
                throw new NegativeExpenseException("Amount must be greater than zero. Please try again.");
            }
            break; // Exit the loop if valid input is given
        } catch (InputMismatchException e) {
            System.out.println("Invalid input. Please enter a valid number for the amount.");
            sc.next(); // Consume the invalid input to prevent infinite loop
        }catch (NegativeExpenseException e) {
            System.out.println("Error: " + e.getMessage());
        }
    }
    return amount;
}

    // Method to display options after adding an expense
    private void showPostAddMenu() {
        try {
            System.out.println("---------------------------------------");
            System.out.println("1. Wanna Add expense!!!");
            System.out.println("2. Do you want to check your expense?");
            System.out.println("3. Go back to home.");
            System.out.println("4. End the system.");
            System.out.print("Choose an option: ");

            pick = sc.nextInt();
            sc.nextLine(); // Consume newline after the int input
            switch (pick) {
                case 1 -> addExpense();
                case 2 -> viewExpenses();
                case 3 -> System.out.println("Returning to the main menu...");
                case 4 -> exitProgram();
                default -> System.out.println("Invalid option. Returning to the main menu...");
            }
        } catch (InputMismatchException e) {
            System.out.println("Invalid input. Please enter a number between 1 and 4.");
            sc.next(); // Consume invalid input
        }
    }

    // Method to view all expenses
    public void viewExpenses() {
        if (expenses.isEmpty()) {
            System.out.println("------------------");
            System.out.println("No expenses recorded.");
        } else {
            System.out.println("------------------");
            System.out.println("^^ Your Expense ^^");
            for (Expense expense : expenses) {
                System.out.println(expense);
            }
        }
        showPostViewMenu();
    }

    // Method to display options after viewing expenses
    private void showPostViewMenu() {
        try {
            System.out.println("......................");
            System.out.println("1. Go back to home.");
            System.out.println("2. Do you want to check your expense?");
            System.out.println("3. End the system");
            System.out.print("Choose an option: ");

            int pick1 = sc.nextInt();
            sc.nextLine(); // Consume newline
            switch (pick1) {
                case 1 -> System.out.println("Returning to the main menu...");
                case 2 -> viewExpenses();
                case 3 -> exitProgram();
                default -> System.out.println("Invalid option. Returning to the main menu...");
            }
        } catch (InputMismatchException e) {
            System.out.println("Invalid input. Please enter a number between 1 and 2.");
            sc.next(); // Consume invalid input
        }
    }

    // Method to exit the program
    private void exitProgram() {
        System.out.println("Bye.... Have a nice day!!!!");
        System.exit(0); // Exit the program
    }

    public void deleteExpense() {
        if (expenses.isEmpty()) {
            System.out.println("------------------");
            System.out.println("No expenses recorded to delete.");
        } else {
            try {
                // Display all expenses with their indices
                System.out.println("^^ Your Expense List ^^");
                for (int i = 0; i < expenses.size(); i++) {
                    System.out.println((i + 1) + ". " + expenses.get(i)); // 1-based index
                }
    
                System.out.print("Enter the number of the expense to delete (1 to " + expenses.size() + "): ");
                int index = sc.nextInt() - 1; // Convert to 0-based index
                sc.nextLine(); // Consume newline
    
                if (index >= 0 && index < expenses.size()) {
                    Expense removedExpense = expenses.remove(index);
                    System.out.println("Deleted Expense: " + removedExpense);
                    System.out.println("Succesfully Deleted........");
                    
                } else {
                    System.out.println("Invalid index. Please enter a valid expense number.");
                }
                showPostViewMenu();
    
            } catch (InputMismatchException e) {
                System.out.println("Invalid input. Please enter a number.");
                sc.next(); // Consume invalid input
            }
        }
    }
    

    // Method to sort expenses by date using selection sort
    public void sortExpensesByDate() {
        for (int i = 0; i < expenses.size() - 1; i++) {
            int minIndex = i;
            for (int j = i + 1; j < expenses.size(); j++) {
                if (expenses.get(j).getDate().compareTo(expenses.get(minIndex).getDate()) < 0) {
                    minIndex = j;
                }
            }
            // Swap the found minimum element with the current element
            Expense temp = expenses.get(i);
            expenses.set(i, expenses.get(minIndex));
            expenses.set(minIndex, temp);
        }
        System.out.println("Expenses sorted by date.");
        viewExpenses();
    }

    // Method to sort expenses by amount using selection sort
    public void sortExpensesByAmount() {
        for (int i = 0; i < expenses.size() - 1; i++) {
            int minIndex = i;
            for (int j = i + 1; j < expenses.size(); j++) {
                if (expenses.get(j).getAmount() < expenses.get(minIndex).getAmount()) {
                    minIndex = j;
                }
            }
            // Swap the found minimum element with the current element
            Expense temp = expenses.get(i);
            expenses.set(i, expenses.get(minIndex));
            expenses.set(minIndex, temp);
        }
        System.out.println("Expenses sorted by amount.");
        viewExpenses();
    }

    // Method to search expenses by category
    public void searchExpensesByCategory() {
        System.out.print("Enter Category to search: ");
        String category = sc.nextLine();
        boolean found = false;

        System.out.println("-----------------------------");
        for (Expense expense : expenses) {
            if (expense.getCategory().equalsIgnoreCase(category)) {
                System.out.println(" Your searching Category Expense is found.");
                System.out.println(expense);
                found = true;
            }
        }

        if (!found) {
            System.out.println("No expenses found for the given category.");
        }
        System.out.println("-----------------------------");

        showPostViewMenu();
    }

    // Method to search expenses by description
    public void searchExpensesByDescription() {
        System.out.print("Enter Description to search: ");
        String description = sc.nextLine();
        boolean found = false;

        System.out.println("-----------------------------");
        for (Expense expense : expenses) {
            if (expense.getDescription().toLowerCase().contains(description.toLowerCase())) {
                System.out.println(" Your searching Description Expense is found.");
                System.out.println(expense);
                found = true;
            }
        }

        if (!found) {
            System.out.println("No expenses found for the given description.");
        }
        System.out.println("-----------------------------");

        showPostViewMenu();
    }
}

// Custom Exception Class for Negative Expense Amounts
class NegativeExpenseException extends Exception {
    public NegativeExpenseException(String message) {
        super(message);
    }
}

// Expense Class
// class Expense {
//     private String date;
//     private String category;
//     private double amount;
//     private String description;

//     public Expense(String date, String category, double amount, String description) {
//         this.date = date;
//         this.category = category;
//         this.amount = amount;
//         this.description = description;
//     }

//     public String getDate() {
//         return date;
//     }

//     public String getCategory() {
//         return category;
//     }

//     public double getAmount() {
//         return amount;
//     }

//     public String getDescription() {
//         return description;
//     }

//     @Override
//     public String toString() {
//         return "Date: " + date + ", Category: " + category + ", Amount: " + amount + ", Description: " + description;
//     }
//}

